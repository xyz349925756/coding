#!/usr/bin/python3
# -*-coding:utf-8-*-
# Auth: xyz34
# File: m1.py
# TIME: 5月  星期日

def f1():
    print("这是f1")
